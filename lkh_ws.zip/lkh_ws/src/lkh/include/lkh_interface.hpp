#ifndef _LKH_INTERFACE_H
#define _LKH_INTERFACE_H

extern "C" {
#include "LKH.h"
#include "Genetic.h"
}

void pkgtest();
int Solve_TSP(const char* filename);

#endif
